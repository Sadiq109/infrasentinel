"""InfraSentinel security log analysis package."""

__version__ = "0.1.0"
